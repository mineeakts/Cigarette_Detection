
Cigarette Detection - v4 2022-06-18 12:49am
==============================

This dataset was exported via roboflow.ai on June 19, 2022 at 7:26 AM GMT

It includes 969 images.
Cigarette are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


